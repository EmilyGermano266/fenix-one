// Fênix One V26 — Proposta de Aparelhos nativa, sem iframe nem redirecionamento.
(()=>{
  'use strict';
  const el=id=>document.getElementById(id);
  const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=v=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(v);
  const clean=v=>String(v||'SEM NOME').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\\/:*?"<>|]/g,'').replace(/\s+/g,' ').trim().slice(0,90);
  const num=v=>{if(typeof v==='number')return Number.isFinite(v)?v:NaN;let x=String(v??'').replace(/R\$|\s/g,'').replace(/[^\d,.-]/g,'');if(x.includes(',')&&x.includes('.'))x=x.lastIndexOf(',')>x.lastIndexOf('.')?x.replace(/\./g,'').replace(',','.'):x.replace(/,/g,'');else if(x.includes(','))x=x.replace(',','.');return Number(x);};
  const data={book:null,rows:[],columns:[],items:[],selected:new Set()};
  const status=t=>{if(el('fx26Status'))el('fx26Status').textContent=t;};
  const normalized=t=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const find=(keys)=>data.columns.find(c=>keys.some(k=>normalized(c).includes(k)))||data.columns[0]||'';
  function mapRows(){
    const m=el('fx26Model')?.value, p=el('fx26Price')?.value, st=el('fx26Stock')?.value;
    data.items=data.rows.map((r,i)=>({id:i,model:String(r[m]??'').trim(),price:num(r[p]),stock:st?num(r[st]):NaN,qty:1})).filter(x=>x.model);
    data.selected.clear();render();
  }
  function fillMapping(){
    data.columns=[...new Set(data.rows.flatMap(r=>Object.keys(r)))];
    for(const id of ['fx26Model','fx26Price','fx26Stock']){
      const select=el(id);select.innerHTML=(id==='fx26Stock'?'<option value="">Não informar</option>':'')+data.columns.map(c=>`<option value="${safe(c)}">${safe(c)}</option>`).join('');
    }
    el('fx26Model').value=find(['modelo','aparelho','produto','descricao','nome']);
    el('fx26Price').value=find(['preco a vista','valor a vista','preco unitario','valor unitario','preco','valor']);
    const st=find(['estoque','quantidade','saldo','disponivel']);
    el('fx26Stock').value=st&&['estoque','quantidade','saldo','disponivel'].some(k=>normalized(st).includes(k))?st:'';
    el('fx26Mapping').classList.remove('hidden');mapRows();
  }
  function sheet(){
    const name=el('fx26Sheet').value;
    data.rows=XLSX.utils.sheet_to_json(data.book.Sheets[name],{defval:'',raw:false});
    if(!data.rows.length){status('Esta aba não contém registros.');return;}
    fillMapping();status(`${data.rows.length} linha(s) carregada(s). Confira as colunas de modelo e preço.`);
  }
  async function upload(file){
    if(!file)return;
    if(typeof XLSX==='undefined'){status('Não foi possível carregar a biblioteca de planilhas.');return;}
    try{
      const buffer=await file.arrayBuffer();data.book=XLSX.read(buffer,{type:'array'});
      el('fx26Sheet').innerHTML=data.book.SheetNames.map(n=>`<option value="${safe(n)}">${safe(n)}</option>`).join('');
      sheet();
    }catch(e){console.error(e);status('Não foi possível ler a planilha. Use CSV, XLS ou XLSX válido.');}
  }
  function filtered(){const q=normalized(el('fx26Search').value).trim();return data.items.filter(i=>!q||normalized([i.model,i.price,i.stock].join(' ')).includes(q));}
  function chosen(){return data.items.filter(i=>data.selected.has(i.id));}
  function render(){
    const list=filtered(),wrap=el('fx26Table');if(!wrap)return;
    if(!data.items.length){wrap.innerHTML='<div class="empty-state">Nenhum aparelho encontrado na planilha.</div>';return;}
    wrap.innerHTML=`<table class="fx26-table"><thead><tr><th>Selecionar</th><th>Modelo</th><th>Preço unitário</th><th>Estoque</th><th>Quantidade desejada</th></tr></thead><tbody>${list.slice(0,500).map(i=>`<tr><td><input type="checkbox" data-fx-select="${i.id}" ${data.selected.has(i.id)?'checked':''} aria-label="Selecionar ${safe(i.model)}"></td><td>${safe(i.model)}</td><td>${Number.isFinite(i.price)&&i.price>0?fmt(i.price):'<strong>Preço inválido</strong>'}</td><td>${Number.isFinite(i.stock)?i.stock:'—'}</td><td><input type="number" min="1" step="1" data-fx-qty="${i.id}" value="${i.qty}" style="max-width:110px"></td></tr>`).join('')}</tbody></table>${list.length>500?'<p>Mostrando os primeiros 500 resultados. Refine a busca para encontrar outros itens.</p>':''}`;
    el('fx26Count').textContent=`${data.selected.size} aparelho(s) selecionado(s).`;
  }
  function validated(){
    const items=chosen();if(!items.length)throw Error('Selecione pelo menos um aparelho.');
    for(const i of items){if(!Number.isFinite(i.price)||i.price<=0)throw Error(`Preço inválido: ${i.model}. Confira a coluna de preço.`);if(!Number.isInteger(i.qty)||i.qty<1)throw Error(`Quantidade inválida: ${i.model}.`);if(Number.isFinite(i.stock)&&i.stock>=0&&i.qty>i.stock)throw Error(`Quantidade maior que o estoque: ${i.model}.`);}
    return items;
  }
  function installments(){return Number(el('fx26Installments').value);}
  function extra(){return Math.max(0,num(el('fx26Extra').value)||0);}
  function proposal(){
    const items=validated(),n=installments(),fee=extra(),client=el('fx26Client').value.trim();if(!client)throw Error('Informe o nome da empresa/cliente.');
    const total=items.reduce((s,i)=>s+i.price*i.qty,0),monthly=total/n+fee;
    el('fx26Document').innerHTML=`<div class="proposal-top"><h2>Vivo Empresas</h2><p>PROPOSTA DE APARELHOS</p><small>Condições sujeitas à disponibilidade de estoque</small></div><div class="client-box"><div><span>CLIENTE</span><strong>${safe(client)}</strong></div><div><span>DATA</span><strong>${new Date().toLocaleDateString('pt-BR')}</strong></div></div><div class="table-wrap"><table><thead><tr><th>Aparelho</th><th>Qtd.</th><th>Unitário</th><th>Total</th></tr></thead><tbody>${items.map(i=>`<tr><td>${safe(i.model)}</td><td>${i.qty}</td><td>${fmt(i.price)}</td><td>${fmt(i.price*i.qty)}</td></tr>`).join('')}</tbody></table></div><div class="fx26-summary"><p>Valor total dos aparelhos: <strong>${fmt(total)}</strong></p><p>Parcelamento: <strong>${n}x de ${fmt(monthly)}</strong></p>${fee?`<p>Acréscimo por parcela: ${fmt(fee)}</p><p>Total com acréscimos: ${fmt(total+fee*n)}</p>`:''}</div>`;
    el('fx26PreviewPanel').classList.remove('hidden');el('fx26PreviewPanel').scrollIntoView({behavior:'smooth',block:'start'});
  }
  function transfer(){
    const items=validated(),n=installments();if(typeof state==='undefined'||!Array.isArray(state.productItems))throw Error('O formulário de proposta não está disponível.');
    if(extra())throw Error('Para transferir à Nova Proposta, deixe o acréscimo por parcela em zero; a proposta comercial não possui esse campo.');
    items.forEach(i=>{const cents=Math.round(i.price*100);state.productItems.push({uid:crypto.randomUUID(),productId:null,category:'aparelho',name:'Aparelho',variant:i.model,priceCents:Math.round(cents/n),benefits:[],type:'new',quantity:i.qty,currentValueCents:0,m:null,countsAsRevenue:false,deviceTotalCents:cents,deviceInstallments:n,deviceInstallmentCents:Math.round(cents/n)});});
    if(typeof renderProducts==='function')renderProducts();if(typeof updateCalc==='function')updateCalc();if(typeof showView==='function')showView('calculatorView');
    if(typeof toast==='function')toast(`${items.length} aparelho(s) incluído(s). Confira os valores.`, 'success');
  }
  function downloadBlob(blob,ext){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=`PROPOSTA - ${clean(el('fx26Client').value)}.${ext}`;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
  document.addEventListener('change',e=>{
    const t=e.target;
    if(t.id==='fx26File')upload(t.files?.[0]);
    if(t.id==='fx26Sheet'&&data.book)sheet();
    if(['fx26Model','fx26Price','fx26Stock'].includes(t.id))mapRows();
    if(t.dataset.fxSelect!==undefined){const id=Number(t.dataset.fxSelect);if(t.checked)data.selected.add(id);else data.selected.delete(id);el('fx26Count').textContent=`${data.selected.size} aparelho(s) selecionado(s).`;}
    if(t.dataset.fxQty!==undefined){const i=data.items.find(x=>x.id===Number(t.dataset.fxQty));if(i)i.qty=Number(t.value);}
  });
  document.addEventListener('input',e=>{if(e.target.id==='fx26Search')render();});
  document.addEventListener('click',async e=>{
    const id=e.target.id;
    try{
      if(id==='fx26SelectAll'){filtered().forEach(i=>data.selected.add(i.id));render();}
      if(id==='fx26Clear'){data.selected.clear();render();}
      if(id==='fx26Generate')proposal();
      if(id==='fx26Transfer')transfer();
      if(id==='fx26Print'){
        const root=el('printRoot');if(!root)throw Error('Área de impressão indisponível.');
        root.innerHTML=el('fx26Document').outerHTML;document.body.classList.add('printing-proposal');
        window.print();setTimeout(()=>{document.body.classList.remove('printing-proposal');root.innerHTML='';},1200);
      }
      if(id==='fx26Image'){
        if(typeof html2canvas==='undefined')throw Error('Biblioteca de imagem indisponível.');
        const canvas=await html2canvas(el('fx26Document'),{backgroundColor:'#ffffff',scale:2});
        canvas.toBlob(blob=>blob?downloadBlob(blob,'png'):alert('Não foi possível gerar a imagem.'));
      }
    }catch(err){alert(err.message||'Não foi possível concluir esta ação.');}
  });
})();
